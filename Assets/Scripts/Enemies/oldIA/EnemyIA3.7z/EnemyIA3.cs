using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.AI;

public class EnemyIA3 : MonoBehaviour
{
    public Transform player;
    public GameObject bulletPrefab;
    private NavMeshAgent agent;
    public LayerMask playerMask;
    public LayerMask obstacleMask;

    private enum Status { PATROL, AGGRO, ATTACK }
    [SerializeField] private Status status;

    // Enemy setting
    public float viewAngle;
    public float sightRange;
    public float attackRange;

    // Condition
    public bool playerInSightRange;
    public bool playerInAttackRange;

    // Patroling
    public Transform[] patrolPoints;
    private int pointsIndex = 1;
    [SerializeField] private Vector3 targetPoint;

    // Attacking
    public float attackRatio = 1f;
    public bool coolDownAttack;


    private void Start()
    {
        //player = GameObject.Find("Player").transform;
        agent = GetComponent<NavMeshAgent>();
        status = Status.PATROL;

        // setto il primo punto da raggiungere
        targetPoint = patrolPoints[pointsIndex].position;
        agent.SetDestination(targetPoint);
    }

    private void Update()
    {
        CheckPlayerInRange();

        if (!playerInSightRange && !playerInAttackRange)
            Patroling();
        if (playerInSightRange && !playerInAttackRange)
            AggroPlayer();
        if (playerInSightRange && playerInAttackRange)
            AttackPlayer();
    }

    // Metodo che controlla se il player � visibile dal nemico e se rientra nella distanza di attacco
    private void CheckPlayerInRange()
    {
        // controllo se il player � nel raggio di aggro del nemico
        bool isPlayerInRange = Physics.CheckSphere(transform.position, sightRange, playerMask);

        // calcolo la distanza tra nemico e player
        float dstToPlayer = Vector3.Distance(transform.position, player.position);

        if (isPlayerInRange)
        {
            // calcolo la direzione verso il player
            Vector3 dirToPlayer = (player.position - transform.position).normalized;

            // se il player � nel campo visivo (la meta del totale campo visivo rispetto a dove sta puntando il nemico)
            if (Vector3.Angle(transform.forward, dirToPlayer) < viewAngle / 2)
            {

                // se il player non � nascosto da ostacoli
                // TODO migliorare caso in cui il raycast intercetti il giocatore attraverso oggetti senza layer Obstacles (pavimenti, ..)
                if (!Physics.Raycast(transform.position, dirToPlayer, dstToPlayer, obstacleMask))
                    playerInSightRange = true;
                else
                    playerInSightRange = false;
            }
            else
                playerInSightRange = false;
        }
        else
            playerInSightRange = false;

        // se il player � nel raggio di aggro del nemico e rientra nella distanza di attacco
        if (playerInSightRange && (dstToPlayer <= attackRange))
            playerInAttackRange = true;
        else
            playerInAttackRange = false;

    }

    private void Patroling()
    {
        SetStatus(Status.PATROL);

        if (Vector3.Distance(transform.position, targetPoint) < 1)
        {
            // aggiorno il prossimo punto da raggiungere e resetto se ho completato un giro
            pointsIndex++;
            if (pointsIndex == patrolPoints.Length)
                pointsIndex = 0;

            targetPoint = patrolPoints[pointsIndex].position;
        }
        // TODO migliorare il set che non serve sempre
        agent.SetDestination(targetPoint);
        agent.isStopped = false;
    }

    private void AggroPlayer()
    {
        SetStatus(Status.AGGRO);
        agent.SetDestination(player.position);
        // TODO non serve reimpostarlo sempre
        agent.isStopped = false;
    }

    private void AttackPlayer()
    {
        SetStatus(Status.ATTACK);

        // il nemico non si muove
        agent.isStopped = true;

        transform.LookAt(player);

        if (!coolDownAttack)
        {
            coolDownAttack = true;
            StartCoroutine(ExecuteAttack());
        }
    }

    private IEnumerator ExecuteAttack()
    {
        GameObject bullet = Instantiate(bulletPrefab, transform.position, Quaternion.identity);
        Rigidbody rb = bullet.GetComponent<Rigidbody>();

        rb.AddForce(transform.forward * 32f, ForceMode.Impulse);
        rb.AddForce(transform.up * 8f, ForceMode.Impulse);

        yield return new WaitForSeconds(attackRatio);

        coolDownAttack = false;
    }
    private void SetStatus(Status status)
    {
        this.status = status;
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.blue;
        Gizmos.DrawWireSphere(transform.position, attackRange);
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(transform.position, sightRange);
    }

}



